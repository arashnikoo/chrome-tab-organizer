function randomColor() {
  const colors = ["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan"];
  return colors[Math.floor(Math.random() * colors.length)];
}
